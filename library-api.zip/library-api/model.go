package main

import "time"

type User struct {
    ID        int64     `json:"id"`
    Name      string    `json:"name"`
    Email     string    `json:"email"`
    CreatedAt time.Time `json:"created_at"`
}

type Item struct {
    ID        int64     `json:"id"`
    Title     string    `json:"title"`
    Author    string    `json:"author"`
    Year      int       `json:"year"`
    ISBN      string    `json:"isbn"`
    CreatedAt time.Time `json:"created_at"`
}

type Loan struct {
    ID         int64      `json:"id"`
    UserID     int64      `json:"user_id"`
    ItemID     int64      `json:"item_id"`
    Status     string     `json:"status"`
    IssuedAt   time.Time  `json:"issued_at"`
    ReturnedAt *time.Time `json:"returned_at,omitempty"`
}

type CreateItemRequest struct {
    Title  string `json:"title"`
    Author string `json:"author"`
    Year   int    `json:"year"`
    ISBN   string `json:"isbn"`
}

type UpdateItemRequest struct {
    Title  string `json:"title"`
    Author string `json:"author"`
    Year   int    `json:"year"`
    ISBN   string `json:"isbn"`
}

type CreateLoanRequest struct {
    UserID int64 `json:"user_id"`
    ItemID int64 `json:"item_id"`
}

type UpdateLoanRequest struct {
    Status string `json:"status"`
}
