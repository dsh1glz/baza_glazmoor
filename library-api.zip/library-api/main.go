package main

import (
    "context"
    "log"
    "net/http"
    "os"
    "time"

    "github.com/jackc/pgx/v5/pgxpool"
)

func getEnv(key, fallback string) string {
    value := os.Getenv(key)

    if value == "" {
        return fallback
    }

    return value
}

func corsMiddleware(next http.Handler) http.Handler {
    return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Access-Control-Allow-Origin", "*")
        w.Header().Set(
            "Access-Control-Allow-Methods",
            "GET, POST, PATCH, DELETE, OPTIONS",
        )
        w.Header().Set(
            "Access-Control-Allow-Headers",
            "Content-Type",
        )

        if r.Method == http.MethodOptions {
            w.WriteHeader(http.StatusNoContent)
            return
        }

        next.ServeHTTP(w, r)
    })
}

func loggingMiddleware(next http.Handler) http.Handler {
    return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        start := time.Now()

        next.ServeHTTP(w, r)

        log.Printf(
            "%s %s %s",
            r.Method,
            r.URL.Path,
            time.Since(start),
        )
    })
}

func main() {
    databaseURL := getEnv(
        "DATABASE_URL",
        "postgres://app:secret@localhost:5432/library?sslmode=disable",
    )

    port := getEnv("PORT", "8080")

    ctx := context.Background()

    db, err := pgxpool.New(ctx, databaseURL)
    if err != nil {
        log.Fatal(err)
    }

    defer db.Close()

    if err := db.Ping(ctx); err != nil {
        log.Fatal(err)
    }

    store := NewLibraryStore(db)

    mux := http.NewServeMux()

    mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
        writeJSON(w, http.StatusOK, map[string]string{
            "status": "ok",
        })
    })

    mux.HandleFunc("/users", store.handleUsers)
    mux.HandleFunc("/items", store.handleItems)
    mux.HandleFunc("/items/", store.handleItems)
    mux.HandleFunc("/loans", store.handleLoans)
    mux.HandleFunc("/loans/", store.handleLoans)

    handler := corsMiddleware(
        loggingMiddleware(mux),
    )

    server := &http.Server{
        Addr:         ":" + port,
        Handler:      handler,
        ReadTimeout:  10 * time.Second,
        WriteTimeout: 10 * time.Second,
    }

    log.Printf("server started on http://localhost:%s", port)

    if err := server.ListenAndServe(); err != nil {
        log.Fatal(err)
    }
}
