const API = "http://localhost:8080";

const booksContainer = document.getElementById("books");
const loansContainer = document.getElementById("loans");

const userSelect = document.getElementById("user-id");
const itemSelect = document.getElementById("item-id");

async function loadBooks() {
    const response = await fetch(`${API}/items`);
    const books = await response.json();

    booksContainer.innerHTML = "";
    itemSelect.innerHTML = "";

    books.forEach(book => {
        const div = document.createElement("div");

        div.className = "book";

        div.innerHTML = `
            <strong>${book.title}</strong>
            <p>${book.author}, ${book.year}</p>
            <p>ISBN: ${book.isbn}</p>
            <button onclick="deleteBook(${book.id})">
                Удалить
            </button>
        `;

        booksContainer.appendChild(div);

        const option = document.createElement("option");

        option.value = book.id;
        option.textContent = `${book.title} — ${book.author}`;

        itemSelect.appendChild(option);
    });
}

async function loadUsers() {
    const response = await fetch(`${API}/users`);
    const users = await response.json();

    userSelect.innerHTML = "";

    users.forEach(user => {
        const option = document.createElement("option");

        option.value = user.id;
        option.textContent = `${user.name} — ${user.email}`;

        userSelect.appendChild(option);
    });
}

async function loadLoans() {
    const response = await fetch(`${API}/loans`);
    const loans = await response.json();

    loansContainer.innerHTML = "";

    loans.forEach(loan => {
        const div = document.createElement("div");

        div.className = "loan";

        div.innerHTML = `
            <p>
                Выдача №${loan.id}
            </p>

            <p>
                Пользователь: ${loan.user_id}
            </p>

            <p>
                Книга: ${loan.item_id}
            </p>

            <p>
                Статус: ${loan.status}
            </p>

            ${
                loan.status === "issued"
                    ? `
                        <button onclick="returnBook(${loan.id})">
                            Вернуть книгу
                        </button>
                    `
                    : ""
            }
        `;

        loansContainer.appendChild(div);
    });
}

async function deleteBook(id) {
    const response = await fetch(`${API}/items/${id}`, {
        method: "DELETE"
    });

    if (response.ok) {
        await loadBooks();
        await loadLoans();
    } else {
        alert("Не удалось удалить книгу");
    }
}

async function returnBook(id) {
    const response = await fetch(`${API}/loans/${id}`, {
        method: "PATCH",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            status: "returned"
        })
    });

    if (response.ok) {
        await loadLoans();
        await loadBooks();
    } else {
        alert("Не удалось вернуть книгу");
    }
}

document
    .getElementById("book-form")
    .addEventListener("submit", async event => {
        event.preventDefault();

        const data = {
            title: document.getElementById("title").value,
            author: document.getElementById("author").value,
            year: Number(document.getElementById("year").value),
            isbn: document.getElementById("isbn").value
        };

        const response = await fetch(`${API}/items`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            event.target.reset();
            await loadBooks();
        } else {
            alert("Не удалось добавить книгу");
        }
    });

document
    .getElementById("loan-form")
    .addEventListener("submit", async event => {
        event.preventDefault();

        const data = {
            user_id: Number(userSelect.value),
            item_id: Number(itemSelect.value)
        };

        const response = await fetch(`${API}/loans`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            await loadLoans();
        } else if (response.status === 409) {
            alert("Эта книга уже выдана");
        } else {
            alert("Не удалось оформить выдачу");
        }
    });

loadBooks();
loadUsers();
loadLoans();