package main

import (
    "context"
    "errors"
    "fmt"

    "github.com/jackc/pgx/v5"
    "github.com/jackc/pgx/v5/pgconn"
    "github.com/jackc/pgx/v5/pgxpool"
)

var ErrNotFound = errors.New("not found")
var ErrAlreadyIssued = errors.New("book is already issued")

type LibraryStore struct {
    db *pgxpool.Pool
}

func NewLibraryStore(db *pgxpool.Pool) *LibraryStore {
    return &LibraryStore{db: db}
}


func (s *LibraryStore) ListUsers(ctx context.Context) ([]User, error) {
    rows, err := s.db.Query(ctx, `
        SELECT id, name, email, created_at
        FROM users
        ORDER BY id
    `)
    if err != nil {
        return nil, err
    }
    defer rows.Close()

    var users []User

    for rows.Next() {
        var u User

        if err := rows.Scan(
            &u.ID,
            &u.Name,
            &u.Email,
            &u.CreatedAt,
        ); err != nil {
            return nil, err
        }

        users = append(users, u)
    }

    if err := rows.Err(); err != nil {
        return nil, err
    }

    return users, nil
}


func (s *LibraryStore) ListItems(ctx context.Context) ([]Item, error) {
    rows, err := s.db.Query(ctx, `
        SELECT id, title, author, year, isbn, created_at
        FROM items
        ORDER BY id
    `)
    if err != nil {
        return nil, err
    }
    defer rows.Close()

    var items []Item

    for rows.Next() {
        var item Item

        if err := rows.Scan(
            &item.ID,
            &item.Title,
            &item.Author,
            &item.Year,
            &item.ISBN,
            &item.CreatedAt,
        ); err != nil {
            return nil, err
        }

        items = append(items, item)
    }

    if err := rows.Err(); err != nil {
        return nil, err
    }

    return items, nil
}

func (s *LibraryStore) GetItem(ctx context.Context, id int64) (Item, error) {
    var item Item

    err := s.db.QueryRow(ctx, `
        SELECT id, title, author, year, isbn, created_at
        FROM items
        WHERE id = $1
    `, id).Scan(
        &item.ID,
        &item.Title,
        &item.Author,
        &item.Year,
        &item.ISBN,
        &item.CreatedAt,
    )

    if errors.Is(err, pgx.ErrNoRows) {
        return Item{}, ErrNotFound
    }

    if err != nil {
        return Item{}, err
    }

    return item, nil
}

func (s *LibraryStore) CreateItem(
    ctx context.Context,
    req CreateItemRequest,
) (Item, error) {
    var item Item

    err := s.db.QueryRow(ctx, `
        INSERT INTO items (title, author, year, isbn)
        VALUES ($1, $2, $3, $4)
        RETURNING id, title, author, year, isbn, created_at
    `,
        req.Title,
        req.Author,
        req.Year,
        req.ISBN,
    ).Scan(
        &item.ID,
        &item.Title,
        &item.Author,
        &item.Year,
        &item.ISBN,
        &item.CreatedAt,
    )

    if err != nil {
        return Item{}, err
    }

    return item, nil
}

func (s *LibraryStore) UpdateItem(
    ctx context.Context,
    id int64,
    req UpdateItemRequest,
) (Item, error) {
    var item Item

    err := s.db.QueryRow(ctx, `
        UPDATE items
        SET title = $1,
            author = $2,
            year = $3,
            isbn = $4
        WHERE id = $5
        RETURNING id, title, author, year, isbn, created_at
    `,
        req.Title,
        req.Author,
        req.Year,
        req.ISBN,
        id,
    ).Scan(
        &item.ID,
        &item.Title,
        &item.Author,
        &item.Year,
        &item.ISBN,
        &item.CreatedAt,
    )

    if errors.Is(err, pgx.ErrNoRows) {
        return Item{}, ErrNotFound
    }

    if err != nil {
        return Item{}, err
    }

    return item, nil
}

func (s *LibraryStore) DeleteItem(ctx context.Context, id int64) error {
    result, err := s.db.Exec(ctx, `
        DELETE FROM items
        WHERE id = $1
    `, id)

    if err != nil {
        return err
    }

    if result.RowsAffected() == 0 {
        return ErrNotFound
    }

    return nil
}


func (s *LibraryStore) ListLoans(ctx context.Context) ([]Loan, error) {
    rows, err := s.db.Query(ctx, `
        SELECT id, user_id, item_id, status, issued_at, returned_at
        FROM loans
        ORDER BY id
    `)
    if err != nil {
        return nil, err
    }
    defer rows.Close()

    var loans []Loan

    for rows.Next() {
        var loan Loan

        if err := rows.Scan(
            &loan.ID,
            &loan.UserID,
            &loan.ItemID,
            &loan.Status,
            &loan.IssuedAt,
            &loan.ReturnedAt,
        ); err != nil {
            return nil, err
        }

        loans = append(loans, loan)
    }

    if err := rows.Err(); err != nil {
        return nil, err
    }

    return loans, nil
}

func (s *LibraryStore) GetLoan(ctx context.Context, id int64) (Loan, error) {
    var loan Loan

    err := s.db.QueryRow(ctx, `
        SELECT id, user_id, item_id, status, issued_at, returned_at
        FROM loans
        WHERE id = $1
    `, id).Scan(
        &loan.ID,
        &loan.UserID,
        &loan.ItemID,
        &loan.Status,
        &loan.IssuedAt,
        &loan.ReturnedAt,
    )

    if errors.Is(err, pgx.ErrNoRows) {
        return Loan{}, ErrNotFound
    }

    if err != nil {
        return Loan{}, err
    }

    return loan, nil
}

func (s *LibraryStore) CreateLoan(
    ctx context.Context,
    req CreateLoanRequest,
) (Loan, error) {
    var loan Loan

    err := s.db.QueryRow(ctx, `
        INSERT INTO loans (user_id, item_id)
        VALUES ($1, $2)
        RETURNING id, user_id, item_id, status, issued_at, returned_at
    `,
        req.UserID,
        req.ItemID,
    ).Scan(
        &loan.ID,
        &loan.UserID,
        &loan.ItemID,
        &loan.Status,
        &loan.IssuedAt,
        &loan.ReturnedAt,
    )

    if err != nil {
        var pgErr *pgconn.PgError

        if errors.As(err, &pgErr) {
            if pgErr.Code == "23505" {
                return Loan{}, ErrAlreadyIssued
            }

            if pgErr.Code == "23503" {
                return Loan{}, fmt.Errorf("user or item not found")
            }
        }

        return Loan{}, err
    }

    return loan, nil
}

func (s *LibraryStore) UpdateLoan(
    ctx context.Context,
    id int64,
    req UpdateLoanRequest,
) (Loan, error) {
    var loan Loan

    err := s.db.QueryRow(ctx, `
        UPDATE loans
        SET status = $1,
            returned_at = CASE
                WHEN $1 = 'returned' THEN now()
                ELSE NULL
            END
        WHERE id = $2
        RETURNING id, user_id, item_id, status, issued_at, returned_at
    `, req.Status, id).Scan(
        &loan.ID,
        &loan.UserID,
        &loan.ItemID,
        &loan.Status,
        &loan.IssuedAt,
        &loan.ReturnedAt,
    )

    if errors.Is(err, pgx.ErrNoRows) {
        return Loan{}, ErrNotFound
    }

    if err != nil {
        return Loan{}, err
    }

    return loan, nil
}

func (s *LibraryStore) DeleteLoan(ctx context.Context, id int64) error {
    result, err := s.db.Exec(ctx, `
        DELETE FROM loans
        WHERE id = $1
    `, id)

    if err != nil {
        return err
    }

    if result.RowsAffected() == 0 {
        return ErrNotFound
    }

    return nil
}
