INSERT INTO users (name, email)
VALUES
    ('Аня Иванова', 'anya@example.com'),
    ('Иван Петров', 'ivan@example.com'),
    ('Мария Соколова', 'maria@example.com')
ON CONFLICT (email) DO NOTHING;

INSERT INTO items (title, author, year, isbn)
VALUES
    ('Мастер и Маргарита', 'Михаил Булгаков', 1967, '9785171182434'),
    ('Преступление и наказание', 'Фёдор Достоевский', 1866, '9785170907205'),
    ('1984', 'Джордж Оруэлл', 1949, '9780451524935'),
    ('Гарри Поттер и философский камень', 'Дж. К. Роулинг', 1997, '9780747532699'),
    ('Три товарища', 'Эрих Мария Ремарк', 1936, '9785699161032')
ON CONFLICT (isbn) DO NOTHING;

INSERT INTO loans (user_id, item_id, status, issued_at, returned_at)
VALUES
    (1, 1, 'issued', now() - INTERVAL '3 days', NULL),
    (2, 2, 'issued', now() - INTERVAL '1 day', NULL),
    (3, 3, 'returned', now() - INTERVAL '5 days', now() - INTERVAL '4 days')
ON CONFLICT DO NOTHING;