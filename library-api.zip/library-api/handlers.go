package main

import (
    "encoding/json"
    "errors"
    "log"
    "net/http"
    "strconv"
    "strings"
)

func writeJSON(w http.ResponseWriter, status int, data any) {
    w.Header().Set("Content-Type", "application/json; charset=utf-8")
    w.WriteHeader(status)
    _ = json.NewEncoder(w).Encode(data)
}

func writeError(w http.ResponseWriter, status int, message string) {
    writeJSON(w, status, map[string]string{
        "error": message,
    })
}

func parseID(r *http.Request) (int64, error) {
    parts := strings.Split(strings.Trim(r.URL.Path, "/"), "/")

    if len(parts) == 0 {
        return 0, errors.New("id is required")
    }

    return strconv.ParseInt(parts[len(parts)-1], 10, 64)
}

// USERS

func (s *LibraryStore) handleUsers(w http.ResponseWriter, r *http.Request) {
    if r.Method != http.MethodGet {
        writeError(w, http.StatusMethodNotAllowed, "method not allowed")
        return
    }

    users, err := s.ListUsers(r.Context())
    if err != nil {
        log.Printf("ListUsers error: %v", err)
        writeError(w, http.StatusInternalServerError, "database error")
        return
    }

    writeJSON(w, http.StatusOK, users)
}

// ITEMS

func (s *LibraryStore) handleItems(w http.ResponseWriter, r *http.Request) {
    switch r.Method {
    case http.MethodGet:
        s.listItems(w, r)

    case http.MethodPost:
        s.createItem(w, r)

    case http.MethodPatch:
        s.updateItem(w, r)

    case http.MethodDelete:
        s.deleteItem(w, r)

    default:
        writeError(w, http.StatusMethodNotAllowed, "method not allowed")
    }
}

func (s *LibraryStore) listItems(w http.ResponseWriter, r *http.Request) {
    items, err := s.ListItems(r.Context())
    if err != nil {
        log.Printf("ListItems error: %v", err)
        writeError(w, http.StatusInternalServerError, "database error")
        return
    }

    writeJSON(w, http.StatusOK, items)
}

func (s *LibraryStore) createItem(w http.ResponseWriter, r *http.Request) {
    var req CreateItemRequest

    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        writeError(w, http.StatusBadRequest, "invalid JSON")
        return
    }

    if strings.TrimSpace(req.Title) == "" ||
        strings.TrimSpace(req.Author) == "" ||
        strings.TrimSpace(req.ISBN) == "" ||
        req.Year <= 0 {
        writeError(w, http.StatusUnprocessableEntity, "invalid item data")
        return
    }

    item, err := s.CreateItem(r.Context(), req)
    if err != nil {
        log.Printf("CreateItem error: %v", err)
        writeError(w, http.StatusInternalServerError, "could not create item")
        return
    }

    writeJSON(w, http.StatusCreated, item)
}

func (s *LibraryStore) updateItem(w http.ResponseWriter, r *http.Request) {
    id, err := parseID(r)

    if err != nil {
        writeError(w, http.StatusBadRequest, "invalid id")
        return
    }

    var req UpdateItemRequest

    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        writeError(w, http.StatusBadRequest, "invalid JSON")
        return
    }

    if strings.TrimSpace(req.Title) == "" ||
        strings.TrimSpace(req.Author) == "" ||
        strings.TrimSpace(req.ISBN) == "" ||
        req.Year <= 0 {
        writeError(w, http.StatusUnprocessableEntity, "invalid item data")
        return
    }

    item, err := s.UpdateItem(r.Context(), id, req)

    if errors.Is(err, ErrNotFound) {
        writeError(w, http.StatusNotFound, "item not found")
        return
    }

    if err != nil {
        log.Printf("UpdateItem error: %v", err)
        writeError(w, http.StatusInternalServerError, "could not update item")
        return
    }

    writeJSON(w, http.StatusOK, item)
}

func (s *LibraryStore) deleteItem(w http.ResponseWriter, r *http.Request) {
    id, err := parseID(r)

    if err != nil {
        writeError(w, http.StatusBadRequest, "invalid id")
        return
    }

    err = s.DeleteItem(r.Context(), id)

    if errors.Is(err, ErrNotFound) {
        writeError(w, http.StatusNotFound, "item not found")
        return
    }

    if err != nil {
        log.Printf("DeleteItem error: %v", err)
        writeError(w, http.StatusInternalServerError, "could not delete item")
        return
    }

    w.WriteHeader(http.StatusNoContent)
}

// LOANS

func (s *LibraryStore) handleLoans(w http.ResponseWriter, r *http.Request) {
    switch r.Method {
    case http.MethodGet:
        s.listLoans(w, r)

    case http.MethodPost:
        s.createLoan(w, r)

    case http.MethodPatch:
        s.updateLoan(w, r)

    case http.MethodDelete:
        s.deleteLoan(w, r)

    default:
        writeError(w, http.StatusMethodNotAllowed, "method not allowed")
    }
}

func (s *LibraryStore) listLoans(w http.ResponseWriter, r *http.Request) {
    loans, err := s.ListLoans(r.Context())

    if err != nil {
        log.Printf("ListLoans error: %v", err)
        writeError(w, http.StatusInternalServerError, "database error")
        return
    }

    writeJSON(w, http.StatusOK, loans)
}

func (s *LibraryStore) createLoan(w http.ResponseWriter, r *http.Request) {
    var req CreateLoanRequest

    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        writeError(w, http.StatusBadRequest, "invalid JSON")
        return
    }

    if req.UserID <= 0 || req.ItemID <= 0 {
        writeError(w, http.StatusUnprocessableEntity, "invalid user_id or item_id")
        return
    }

    loan, err := s.CreateLoan(r.Context(), req)

    if errors.Is(err, ErrAlreadyIssued) {
        writeError(w, http.StatusConflict, "book is already issued")
        return
    }

    if err != nil {
        log.Printf("CreateLoan error: %v", err)
        writeError(w, http.StatusInternalServerError, "could not create loan")
        return
    }

    writeJSON(w, http.StatusCreated, loan)
}

func (s *LibraryStore) updateLoan(w http.ResponseWriter, r *http.Request) {
    id, err := parseID(r)

    if err != nil {
        writeError(w, http.StatusBadRequest, "invalid id")
        return
    }

    var req UpdateLoanRequest

    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        writeError(w, http.StatusBadRequest, "invalid JSON")
        return
    }

    if req.Status != "issued" && req.Status != "returned" {
        writeError(w, http.StatusUnprocessableEntity, "invalid status")
        return
    }

    loan, err := s.UpdateLoan(r.Context(), id, req)

    if errors.Is(err, ErrNotFound) {
        writeError(w, http.StatusNotFound, "loan not found")
        return
    }

    if err != nil {
        log.Printf("UpdateLoan error: %v", err)
        writeError(w, http.StatusInternalServerError, "could not update loan")
        return
    }

    writeJSON(w, http.StatusOK, loan)
}

func (s *LibraryStore) deleteLoan(w http.ResponseWriter, r *http.Request) {
    id, err := parseID(r)

    if err != nil {
        writeError(w, http.StatusBadRequest, "invalid id")
        return
    }

    err = s.DeleteLoan(r.Context(), id)

    if errors.Is(err, ErrNotFound) {
        writeError(w, http.StatusNotFound, "loan not found")
        return
    }

    if err != nil {
        log.Printf("DeleteLoan error: %v", err)
        writeError(w, http.StatusInternalServerError, "could not delete loan")
        return
    }

    w.WriteHeader(http.StatusNoContent)
}
